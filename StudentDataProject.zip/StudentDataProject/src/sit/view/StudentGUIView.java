/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sit.view;

import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

/**
 *
 * @author INT105
 */
public class StudentGUIView {
    
    private JFrame frameStudent;
    private JPanel jpnStudentRecord;
    private JPanel jpnBotton;
    private JPanel jpnStudentTable;
    private JPanel jpnStudentLeft;
    
    private JTextField txtStdFirstName;
    private JTextField txtStdLastName;
    private JTextField txtStdId;
    
    private JButton btnSave;
    private JButton btnSaveAs;
    private JButton btnReset;
    
    private JTable tblStudent;
    private JScrollPane scrlStudent;
    
    public StudentGUIView() {
        initGUI();
    }
    
    private void initGUI() {
        frameStudent = new JFrame("Student List");
        jpnStudentRecord = new JPanel(new GridLayout(3, 2));
        
        jpnStudentRecord.add(new JLabel("Student ID "));
        txtStdId = new JTextField();
        jpnStudentRecord.add(txtStdId);
        
        jpnStudentRecord.add(new JLabel("First name"));
        txtStdFirstName = new JTextField();
        jpnStudentRecord.add(txtStdFirstName);
        
        jpnStudentRecord.add(new JLabel("Last name"));
        txtStdLastName = new JTextField();
        jpnStudentRecord.add(txtStdLastName);
        
        jpnBotton = new JPanel();
        btnSave = new JButton("Save");
        btnSaveAs = new JButton("Save As Object");
        btnReset = new JButton("Reset");
        
        jpnBotton.add(btnSave);
        jpnBotton.add(btnSaveAs);
        jpnBotton.add(btnReset);
        
        jpnStudentLeft = new JPanel(new BorderLayout());
        jpnStudentLeft.add(jpnStudentRecord, BorderLayout.NORTH);
        jpnStudentLeft.add(jpnBotton, BorderLayout.CENTER);
        
        jpnStudentTable = new JPanel();
        tblStudent = new JTable();
        
        scrlStudent = new JScrollPane();
        scrlStudent.add(tblStudent);
        jpnStudentTable.add(scrlStudent);
        
        frameStudent.add(jpnStudentLeft, BorderLayout.WEST);
        frameStudent.add(jpnStudentTable, BorderLayout.CENTER);
        frameStudent.setSize(700, 400);
        frameStudent.setVisible(true);
        frameStudent.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
}
